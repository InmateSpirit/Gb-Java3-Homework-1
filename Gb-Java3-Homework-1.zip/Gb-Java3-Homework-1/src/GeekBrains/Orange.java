package GeekBrains;

public class Orange extends Fruits {

}
