package GeekBrains;

public class Apple extends Fruits {
}
