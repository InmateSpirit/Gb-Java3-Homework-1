package GeekBrains;

public abstract class Fruits {
    float weight;
}
